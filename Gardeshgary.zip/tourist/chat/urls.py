from django.urls import path, include
from . import views

urlpatterns = [
    path("chat-with-leader/", views.chat, name='chat'),
    path("delete-account/<int:idu>/", views.delete, name='remove')
]
