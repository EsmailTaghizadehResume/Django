from django.contrib import admin
from .models import message

# Register your models here.
admin.site.register(message)