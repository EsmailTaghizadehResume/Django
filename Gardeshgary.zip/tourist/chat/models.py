from django.db import models
from account.models import Chat_Room

# Create your models here.
class message(models.Model):
    room = models.ForeignKey(Chat_Room, on_delete=models.CASCADE)
    user = models.CharField(max_length=10)
    text = models.TextField()
    time = models.CharField(max_length=20)