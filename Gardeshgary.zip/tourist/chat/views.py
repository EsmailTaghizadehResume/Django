from django.shortcuts import render, redirect
from Home.views import home
from account.models import Accounts2, Chat_Room
from chat.models import message
import time

# Create your views here.
def chat(requests):
    now_time = time.localtime(time.time())
    current_time = f'{now_time.tm_hour}:{now_time.tm_min}'
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR')

    user = None
    for _ in list(Accounts2.objects.all()):
        if _.ip == ip:
            user = _
            break

    chatt = None
    for _ in list(Chat_Room.objects.all()):
        if _.ip == user.ip:
            chatt = _
            break
    chats = list(message.objects.filter(room__ip=ip))
    if requests.method == 'POST':
        new_message = message(room=chatt, user='user', text=requests.POST['text'], time=current_time)
        new_message.save()
        chatt.status = 'not-read-admin'
        chatt.save()
        return redirect(chat)
    # this is for searching user in Account's 
    for i in list(Accounts2.objects.all()):
        if i.ip == ip:
            return render(requests, 'user_chat.html', {'user':i, 'chats':chats})
    else:
        return render(requests, '404.html')
    
    
def delete(requests, idu):
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR')
    # this is for finding user and remove the ip and password to have the chatroom
    for i in list(Accounts2.objects.all()):
        if i.ip == ip:
            user = Accounts2.objects.get(id=idu)
            user.ip = ''
            user.password = '####'
            user.save()
            return redirect(home)
        
    else:
        return render(requests, '404.html')