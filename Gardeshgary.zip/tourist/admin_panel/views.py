from django.shortcuts import render,redirect
from account.models import Accounts2, Chat_Room
from Home.models import user_message, views
from product.models import Reserve, Items
from chat.models import message
from .forms import travel
import datetime
import time

# Create your views here.
# this is for user managing
def users_page(requests):
    return render(requests, 'admin_panel/users.html', {'users':list(Accounts2.objects.all())})
def delete_user(requests, idu):
    Accounts2.objects.get(id=idu).delete()
    return redirect(users_page)
# --------------------------------

# this is for travling items
def items(requests):
    if requests.method == 'POST':
        new_travel = Items(title=requests.POST['title'], desc=requests.POST['text'], price=requests.POST['price'], status='ok')
        new_travel.save()
        return render(requests, 'admin_panel/items.html', {'item':list(Items.objects.all()), 'form':travel()})
    else:
        return render(requests, 'admin_panel/items.html', {'item':list(Items.objects.all()), 'form':travel()})
def remove_items(requests, idp):
    Items.objects.get(id=idp).delete()
    return redirect(items)
def accept(requests, idp):
    item = Items.objects.get(id=idp)
    item.status = 'ok'
    item.save()
    return redirect(items)
def disable(requests, idp):
    item = Items.objects.get(id=idp)
    item.status = 'finish'
    item.save()
    return redirect(items)
# ----------------------------------

# this is for user text's
def texts(requests):
    return render(requests, 'admin_panel/comments.html', {'text':list(user_message.objects.all())})
def delete_texts(requests, idc):
    user_message.objects.get(id=idc).delete()
    return redirect(texts)
# -----------------------------------

# this is for show amar
def amar(requests):
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # toda views counting
    view_today = 0
    for _ in list(views.objects.all()):
        if _.date == now_date:
            view_today += 1
    
    # today sign up counting
    sign_up_today = 0
    for _ in list(Accounts2.objects.all()):
        if _.date == now_date:
            sign_up_today += 1

    # today reserve counting
    reserve_count = 0
    for _ in list(Reserve.objects.all()):
        if _.date == now_date:
            reserve_count += 1

    return render(requests, 'admin_panel/amar.html', {'all_views':len(list(views.objects.all())), 'all_users':len(list(Accounts2.objects.all())), 'all_text':len(list(user_message.objects.all())),
                                                    'today_v':view_today, 'today_s':sign_up_today, 'all_reserver':len(list(Reserve.objects.all())), 'today_r':reserve_count,
                                                    'reserving':list(Reserve.objects.all())})
# ------------------------------------

# this is for reject
def reject(requests, idi):
    item = Reserve.objects.get(id=idi)
    item.status = 'not_ok'
    item.save()
    return redirect(amar)

# this is for confirm
def confirm(requests, idi):
    item = Reserve.objects.get(id=idi)
    item.status = 'ok'
    item.save()
    return redirect(amar)

# this is for delete all reserve's
def delete_all(requests):
    Reserve.objects.all().delete()
    return redirect(amar)

# this is for deleting all not ok users
def delete_not_ok(requests):
    for i in list(Reserve.objects.all()):
        if i.status == 'not_ok':
            Reserve.objects.get(id=i.id).delete()
    return redirect(amar)

def chat(requests):
    now_time = time.localtime(time.time())
    current_time = f'{now_time.tm_hour}:{now_time.tm_min}'
    # all methods for chat page
    try:
        all_chat_rooms = list(Chat_Room.objects.all())
        first = all_chat_rooms[0]
        chats = list(message.objects.filter(room__ip=first.ip))
    except:
        all_chat_rooms = []
        first = []
        chats = []

    if requests.method == 'POST':
        if len(list(requests.POST)) == 3:
            for _ in Chat_Room.objects.all():
                message_to_all = message(room=_, user='admin', text=requests.POST['text'], time='')
                _.status = 'not-read-user'
                _.save()
                message_to_all.save()
            return redirect(chat)
        if len(list(requests.POST)) == 2:
            new_message = message(room=first, user='admin', text=requests.POST['text'], time=current_time)
            first.status = 'not-read-user'
            new_message.save()
            first.save()
            return redirect(chat)

    return render(requests, 'admin_panel/chat.html', {'users':all_chat_rooms, 'first':first, 'message':chats})

def chat_user_n(requests, idu):
    now_time = time.localtime(time.time())
    current_time = f'{now_time.tm_hour}:{now_time.tm_min}'
    # all methods for chat page
    try:
        all_chat_rooms = list(Chat_Room.objects.all())
        first = Chat_Room.objects.get(id=idu)
        first.status = 'read'
        first.save()
        chats = list(message.objects.filter(room__ip=first.ip))
    except:
        all_chat_rooms = []
        first = []
        chats = []

    if requests.method == 'POST':
        if len(list(requests.POST)) == 3:
            for _ in list(Chat_Room.objects.all()):
                message_to_all = message(room=_, user='admin', text=requests.POST['text'], time='')
                _.status = 'not-read-user'
                _.save()
                message_to_all.save()
            return redirect(chat_user_n, idu)
        if len(list(requests.POST)) == 2:
            new_message = message(room=first, user='admin', text=requests.POST['text'], time=current_time)
            first.status = 'not-read-user'
            new_message.save()
            first.save()
            return redirect(chat_user_n, idu)

    return render(requests, 'admin_panel/user_n.html', {'users':all_chat_rooms, 'first':first, 'message':chats})
