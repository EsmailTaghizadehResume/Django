from django import forms
from product.models import Items

# this is all forms class 
# this is for add travel class
class travel(forms.ModelForm):
    # this is for creating our fields
    class Meta:
        model = Items
        fields = ['title', 'desc', 'price']