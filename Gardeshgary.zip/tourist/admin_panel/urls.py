from django.urls import path, include
from . import views

urlpatterns = [
    path('users-manager/', views.users_page, name='user'),
    path('users-delete/<int:idu>/', views.delete_user, name='delete-user'),

    path('travel-manager/', views.items, name='items'),
    path('travel-delete/<int:idp>/', views.remove_items, name='delete-items'),
    path('travel-accept/<int:idp>/', views.accept, name='accept-items'),
    path('travel-diable/<int:idp>/', views.disable, name='disable-items'),

    path('comments-manager/', views.texts, name='comments'),
    path('comments-delete/<int:idc>/', views.delete_texts, name='delete-comments'),

    path('amar-manager/', views.amar, name='amar'),

    path('reject-reserve/<int:idi>/', views.reject, name='reject'),
    path('conform-reserve/<int:idi>/', views.confirm, name='confirm'),

    path('delete-all/', views.delete_all, name='delete-all'),
    path('delete-not-ok/', views.delete_not_ok, name='delete-not-ok'),

    path('chat-with-me/', views.chat, name='chat-admin'),
    path('caht-with-user/<int:idu>/', views.chat_user_n, name='user'),
]
