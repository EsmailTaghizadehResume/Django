from django.contrib import admin
from .models import Items, Reserve

# Register your models here.
admin.site.register(Items)
admin.site.register(Reserve)