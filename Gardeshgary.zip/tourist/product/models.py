from django.db import models
from account.models import Accounts2

# Create your models here.
class Items(models.Model):
    title = models.CharField(max_length=250)
    desc = models.TextField()
    price = models.CharField(max_length=100)
    status = models.CharField(max_length=20)


class Reserve(models.Model):
    user = models.ForeignKey(Accounts2, on_delete=models.CASCADE)
    item = models.CharField(max_length=250)
    date = models.CharField(max_length=20)
    status = models.CharField(max_length=20)
    