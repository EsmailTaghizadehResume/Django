from django.db import models

# Create your models here.
class Accounts2(models.Model):
    ip = models.CharField(max_length=20)
    name = models.CharField(max_length=250)
    date = models.CharField(max_length=20)
    password = models.CharField(max_length=18)
    number = models.CharField(max_length=20)

class Chat_Room(models.Model):
    ip = models.CharField(max_length=20)
    date = models.CharField(max_length=20)
    user = models.ForeignKey(Accounts2, on_delete=models.CASCADE)
    status = models.CharField(max_length=20)