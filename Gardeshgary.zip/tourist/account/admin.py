from django.contrib import admin
from .models import Accounts2, Chat_Room

# Register your models here.
admin.site.register(Accounts2)
admin.site.register(Chat_Room)