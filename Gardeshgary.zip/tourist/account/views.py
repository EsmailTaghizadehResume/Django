from django.shortcuts import render, redirect
from .models import Accounts2, Chat_Room
import datetime

# Create your views here.
def reg(requests):
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 

    # this is for request and responding
    if requests.method == 'POST':
        for i in list(Accounts2.objects.all()):
            if i.number == requests.POST['Number'] or i.name == requests.POST['Name']:
                return render(requests, 'register.html', {'user':True})
        else:
            new_user = Accounts2(ip=ip, date=now_date, name=requests.POST['Name'], password=requests.POST['Password'], number=requests.POST['Number'])
            new_user.save()

            new_chat_room = Chat_Room(ip=ip, date=now_date, user=new_user)
            new_chat_room.save()

            return render(requests, 'message.html')
    else:
        return render(requests, 'register.html',{'user':False})