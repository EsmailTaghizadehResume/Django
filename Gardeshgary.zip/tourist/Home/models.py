from django.db import models
from account.models import Accounts2

# Create your models here.
class views(models.Model):
    ip = models.CharField(max_length=20)
    date = models.CharField(max_length=20)
    name = models.CharField(max_length=250)

class user_message(models.Model):
    ip = models.CharField(max_length=20)
    date = models.CharField(max_length=30)
    name = models.CharField(max_length=250)
    number = models.CharField(max_length=20)
    message = models.TextField()

