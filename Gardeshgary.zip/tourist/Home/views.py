from django.shortcuts import render, redirect
from account.models import Accounts2, Chat_Room
from account.views import reg
from admin_panel.views import users_page
from .models import user_message, views
from product.models import Reserve, Items
import datetime

# Create your views here.
def home(requests):
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 
   
    user_name = ''
    user = False
    chatroom = False
    for _ in list(Accounts2.objects.all()):
        if _.ip == ip:
            user = True
            for i in list(Chat_Room.objects.all()):
                if i.ip == ip:
                    if i.status == 'not-read-user':
                        chatroom = True
                        break
            break

     # this is for saving views
    for _ in list(views.objects.all()):
        if _.ip == ip and _.date == now_date:
            break
    else:
        if user_name != '':
            new_view = views(ip=ip, date=now_date, name=user_name)
            new_view.save()
        else:
            new_view = views(ip=ip, date=now_date, name='ناشناس')
            new_view.save()
    # this is for requesting and responsing
    if requests.method == 'POST':
        # this is for saving user text 
        if len(requests.POST) == 4:
            all_text = list(user_message.objects.all())
            for i in all_text:
                if i.ip == ip and i.message == requests.POST['text']:
                    return render(requests, 'index.html' , {'alert':'ntt'})
            else:
                if requests.POST['name'] != '' or requests.POST['number'] != '' or requests.POST['text'] != '' and ('09' in requests.POST['number'] ):
                    new_text = user_message(ip=ip, name=requests.POST['name'], number=requests.POST['number'], message=requests.POST['text'], date=now_date)
                    new_text.save()
                    return render(requests, 'index.html' , {'alert':'ok', 'user':user, 'items':list(Items.objects.all()), 'chatroom':chatroom})
                else:
                    return render(requests, 'index.html' , {'alert':'not', 'user':user, 'items':list(Items.objects.all()), 'chatroom':chatroom})
        # this is for log in post
        elif len(requests.POST) == 3:
            if requests.POST['Name'] == 'esi' and requests.POST['Password'] == '123':
                    return redirect(users_page)
            else:
                for _ in list(Accounts2.objects.all()):
                    if _.name == requests.POST['Name'] and _.password == requests.POST['Password']:
                        _.ip = ip
                        _.save()
                        return redirect(home)
                else:
                    return redirect(reg)
        else:
            return render(requests, 'index.html', {'alert':False, 'user':user, 'items':list(Items.objects.all()), 'chatroom':chatroom})
    else:
        return render(requests, 'index.html', {'alert':False, 'user':user, 'items':list(Items.objects.all()), 'chatroom':chatroom})
    
def reserveing(requests, idt):
    reserve = False
    # this is for item
    travel = Items.objects.get(id=idt)
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 

    # this is for finding user 
    for i in list(Accounts2.objects.all()):
        if i.ip == ip:
            new_reserve = Reserve(user=i, item=travel.title, date=now_date, status='dontknow')
            new_reserve.save()
            reserve = True
            break


    return render(requests, 'reserve.html', {'reserve':reserve})
    
