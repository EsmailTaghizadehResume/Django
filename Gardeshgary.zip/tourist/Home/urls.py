from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('reserving.../<int:idt>/', views.reserveing, name='reserve'),
    path('register/', include('account.urls')),
    path('manager/', include('admin_panel.urls')),
    path('chat/', include('chat.urls'))
]
