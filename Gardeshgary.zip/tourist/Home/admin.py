from django.contrib import admin
from .models import views, user_message

# Register your models here.
admin.site.register(views)
admin.site.register(user_message)