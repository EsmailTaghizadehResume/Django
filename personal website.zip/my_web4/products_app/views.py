from django.shortcuts import render, redirect
from accounts.views import reg
from accounts.models import All_User
from products_app.models import Reserve_products2
from home.models import Products
import datetime

# Create your views here.
def booking(requests, idp):
    product = Products.objects.get(id=idp)
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this is for finding user ip
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 

    user = None
    flag = False
    for i in list(All_User.objects.all()):
        if i.ip == ip:
            flag = True
            user  = i
            break

    if flag:
        for i in list(Reserve_products2.objects.all()):
            if i.name == user.name and i.product_name == product.title:
                return render(requests, 'loading.html')
        else:
            new_reserve = Reserve_products2(date=now_date, ip=ip, product_name=product.title, status='not', name=user.name, message=user.phone)
            new_reserve.save()
            return render(requests, 'loading.html')
    else:
        return redirect(reg)