from django.contrib import admin
from .models import About, Reserve_products2

# Register your models here.
admin.site.register(About)
admin.site.register(Reserve_products2)