from django.db import models


# this is all models
class About(models.Model):
    title = models.CharField(max_length=250)
    description = models.TextField()
    rules = models.TextField()
    photo = models.ImageField(upload_to='about-projects/')

# this is not use
# ---------------------------------------------------
class Reserve_products(models.Model):
    date = models.CharField(max_length=50)
    ip = models.CharField(max_length=100)
    product_name = models.CharField(max_length=250)
    message = models.TextField()
# ----------------------------------------------------

class Reserve_products2(models.Model):
    date = models.CharField(max_length=50)
    ip = models.CharField(max_length=100)
    product_name = models.CharField(max_length=250)
    message = models.TextField()
    status = models.CharField(max_length=20)
    name = models.CharField(max_length=250)