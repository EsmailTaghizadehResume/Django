from django.db import models

# Create your models here.
# this is the last update 
class All_User(models.Model):
    name = models.CharField(max_length=250)
    Email = models.CharField(max_length=250)
    phone = models.CharField(max_length=200)
    password = models.CharField(max_length=12)
    ip = models.CharField(max_length=20)
    date = models.CharField(max_length=20)

# this is for saving all views in django
class All_Views(models.Model):
    ip = models.CharField(max_length=20)
    date = models.CharField(max_length=150)

# this for chatrooms
class room(models.Model):
    email = models.CharField(max_length=250)
    status = models.CharField(max_length=30)
    last_seen = models.CharField(max_length=50)
    start_at = models.CharField(max_length=150)
    name = models.CharField(max_length=200)
    number = models.CharField(max_length=100)


# this is for message
class message(models.Model):
    chat_room = models.ForeignKey(room, on_delete=models.CASCADE)
    time = models.CharField(max_length=100)
    text = models.TextField()
    user = models.CharField(max_length=100)

