from django.shortcuts import render
from .models import All_User, room, message
from home.models import Products, Resume_Project
import admin_panel.views as ad # it work !!
import datetime
import time

# Create your views here.
# This is login System
USER = []
def login(requests):
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP-X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR')
    # ------------------------------------------------------------------------------------

    if requests.method == 'POST':
        try:
            all_users = All_User.objects.get(Email=requests.POST['Email'])
        except:
            all_users = []
        finally:
            if requests.POST['Email'] == '123@gmail.com' and requests.POST['Password'] == '123':
                return ad.modir(requests)
            elif all_users:
                if requests.POST['Password'] == all_users.password:
                    all_users.ip = ip
                    all_users.save()
                    # showing home with alert
                    resume = list(Resume_Project.objects.all())
                    products = list(Products.objects.all())
                    # creating slice for just 3 from end to start in all product
                    # this is a target list
                    if len(products) == 0:
                        all_products = []
                    elif len(products) == 1:
                        all_products = [products[0]]
                    elif len(products) == 2:
                        all_products = [products[0], products[1]]
                    else:
                        all_products = [products[-1], products[-2], products[-3]]

                    USER.append(all_users)
                    return render(requests, 'index.html', {'alert':'user', 'items':all_products, 'resume':resume, 'user':USER[0]})
                else:
                    alert = 'no password'
                    return render(requests, 'autentication/login.html', {'alert':alert})
            else:
                alert = 'no user'
                return render(requests, 'autentication/login.html', {'alert':alert})
    else:
        return render(requests, 'autentication/login.html', {'alert':0})


# This is Registeration System
def reg(requests):
    # date and time both
    current_time = time.localtime()
    string_time = time.strftime("%d/%m/%Y - %H:%M", current_time)
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")

    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP-X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR')
    # this action of requsts
    if requests.method == 'POST':
        flag = False # this is for checking emails and phone number
        all_users = All_User.objects.all()
        # this loop for checking
        for i in all_users:
            if requests.POST['Email'] == i.Email or requests.POST['Number'] == i.phone:
                flag = True
                break
        if flag == True:
            return render(requests, 'autentication/forward.html', {'alert':'same'})
        else:
            # Create user
            new_user = All_User(name=requests.POST['Name'], Email=requests.POST['Email'], phone=requests.POST['Number'], password=requests.POST['Password'], ip=ip, date=now_date)
            new_user.save()
            # createing room for user
            new_room = room(email=requests.POST['Email'], status='off', last_seen='None', start_at=string_time, name=requests.POST['Name'], number=requests.POST['Number'])
            new_room.save()

            print(new_room.start_at)

            return render(requests, 'autentication/forward.html', {'name':requests.POST['Name']})
    else:
        return render(requests, 'autentication/register.html', {'alert':0})

def forgot(requests):
    if requests.method == 'POST':
        all_users = All_User.objects.all()
        for i in all_users:
            if requests.POST['Email'] == i.Email and requests.POST['Number'] == i.phone:
                return render(requests, 'autentication/info.html', {'user' : i})
        return render(requests, 'autentication/forgot-password.html', {'alert':'no'})
    else:
        return render(requests, 'autentication/forgot-password.html', {'alert':0})