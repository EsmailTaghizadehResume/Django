from django.contrib import admin
from .models import All_User, All_Views, room, message

# Register your models here.
admin.site.register(All_User)
admin.site.register(All_Views)
admin.site.register(room)
admin.site.register(message)