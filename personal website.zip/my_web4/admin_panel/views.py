from django.shortcuts import render, redirect
from accounts.models import All_User, All_Views, room, message
from home.models import Resume_Project, Products, user_text2
from products_app.models import About, Reserve_products2
from .models import view_info
from .forms import Resume_Projects_Form, ProductForm
import datetime

# Create your views here.
def modir(requests): 
    # this is now variable
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this is all length in all queries
    all_users = len(list(All_User.objects.all()))
    all_products = len(list(Products.objects.all()))
    all_resume = len(list(Resume_Project.objects.all()))
    all_views = len(list(All_Views.objects.all()))
    all_reserve = len(list(Reserve_products2.objects.all()))

    # this is for now views
    now_view = 0
    for _ in All_Views.objects.all():
        if _.date == now_date:
            now_view += 1

    return render(requests, 'admin_pages/index.html', {'users':all_users, 'reserve':all_reserve,'products':all_products, 'resume':all_resume, 'view':all_views, 'now':now_view, 'view_info':list(All_Views.objects.all())[-1::]})

def user_texts(requests):
    all_commands =  list(user_text2.objects.all())
    print(all_commands)
    return render(requests, 'admin_pages/comments.html', {'texts':all_commands})

def product(requests):
    if requests.method == 'POST':
        new_product = Products(title=requests.POST['title'], description=requests.POST['description'], photo=requests.POST['photo'], category=requests.POST['category'])
        new_product.save()
        return redirect(product)
    else:
        all_product = list(Products.objects.all())
        return render(requests, 'admin_pages/products.html', {'product':all_product, 'form':ProductForm})

def user(requests):
     # this is now variable
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    
    if requests.method == 'POST':
        flag = False # this is for checking emails and phone number
        all_users = All_User.objects.all()
        # this loop for checking
        for i in all_users:
            if requests.POST['email'] == i.Email or requests.POST['number'] == i.phone:
                flag = True
                break
        if flag == True:
            return render(requests, 'autentication/forward.html', {'alert':'same'})
        else:
            new_user = All_User(name=requests.POST['name'], Email=requests.POST['email'], phone=requests.POST['number'], password=requests.POST['psw'], ip='0.0.0.0', date=now_date)
            new_user.save()
            return redirect(user)
            
    else:
        all_user = All_User.objects.all()
        return render(requests, 'admin_pages/users.html', {'user':all_user})

def delete_acoount(requests, idu):
    all_user = All_User.objects.get(id=idu).delete()
    return redirect(user)

def delete_product(requests, idp):
    all_product = Products.objects.get(id=idp).delete()
    return redirect(product)

def delete_text(requests, idt):
    all_product = user_text2.objects.get(id=idt).delete()
    return redirect(user_texts)

def resume(requests):
    if requests.method == 'POST':
        new_resume = Resume_Project(title=requests.POST['title'], description=requests.POST['description'],skills=requests.POST['skills'], time_to_finish=requests.POST['time_to_finish'], url=requests.POST['url'], photo=requests.POST['photo'])
        new_resume.save()
        return redirect(resume)
    else:
        all_resume = list(Resume_Project.objects.all())
        return render(requests, 'admin_pages/resume.html', {'resume':all_resume, 'form':Resume_Projects_Form})

def delete_resume(requests, idr):
    all_resume = Resume_Project.objects.get(id=idr).delete()
    return redirect(resume)

def reserve(requests):
    all_reserve = list(Reserve_products2.objects.all())
    return render(requests, 'admin_pages/tickets.html', {'reserve':all_reserve})

def view(requests):
    all_user = list(All_User.objects.all())
    all_view = list(All_Views.objects.all())
    # this is now variable
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")

    # this loop for counting view of today
    now_count = 0
    for _ in All_Views.objects.all():
        if _.date == now_date:
            now_count += 1

    # this loop for counting sign up to day
    today_sign_up = 0
    for _ in all_user:
        if _.date == now_date:
            today_sign_up += 1

    # this for add 100 views to view panel
    all = view_info.objects.all().delete()
    for j, _ in enumerate(all_view):
        if j < 99:
            for i in all_user:
                if i.ip == _.ip:
                    new_view = view_info(name=i.name, date=_.date, ip=_.ip)
                    new_view.save()
                    break
            else:
                new_view = view_info(name='ثبت نشده', date=_.date, ip=_.ip)
                new_view.save()
        else:
            break
    print(list(view_info.objects.all()))

    return render(requests, 'admin_pages/views_user.html', {'view':view_info.objects.all() ,'allView':len(all_view), 'nowView':now_count, 'allUser':len(all_user), 'todayS': today_sign_up})

def about(requests):
    all_about = About.objects.all()
    return render(requests, 'admin_pages/user-information.html', {'items':all_about})

def chats(requests):
    # this is for time H:M
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M")
    # this is other variables
    all_rooms = list(room.objects.all())
    default = all_rooms[0]
    default.start_at = False
    default.save()
    all_message = message.objects.filter(chat_room__email=default.email).all()
    if requests.method == 'POST':
        new_message = message(chat_room=default, time=current_time, text=requests.POST['text'], user='admin')
        new_message.save()
        return redirect(chats)
    else:
        return render(requests, 'admin_pages/chat.html', {'rooms':all_rooms, 'user':default, 'message':all_message})


def chat_with(requests, user_id):
    # this is for time H:M
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M")
    # this is other variables
    all_rooms = list(room.objects.all())
    user = room.objects.get(id=user_id)
    user.start_at = False
    user.save()
    all_message = message.objects.filter(chat_room__name=user.name).all()
    if requests.method == 'POST':
        new_message = message(chat_room=user, time=current_time, text=requests.POST['text'], user='admin')
        new_message.save()
        all_rooms = list(room.objects.all())
        user = room.objects.get(id=user_id)
        return render(requests, 'admin_pages/chat.html', {'rooms':all_rooms, 'user':user, 'message':all_message})

    else:
        return render(requests, 'admin_pages/chat.html', {'rooms':all_rooms, 'user':user, 'message':all_message})
