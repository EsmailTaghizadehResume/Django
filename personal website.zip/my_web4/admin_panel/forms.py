from django import forms
from home.models import Products, Resume_Project
from products_app.models import About, Reserve_products2
from accounts.models import All_User


# this is all models form class
class ProductForm(forms.ModelForm):
    # specify the name of model to use
    class Meta:
        model = Products
        fields = "__all__"

class Resume_Projects_Form(forms.ModelForm):
    # calss for resume Form Meta 
    class Meta:
        model = Resume_Project
        fields = "__all__"

class AboutForm(forms.ModelForm):
    # class for About Form
    class Meta:
        model = About
        fields = "__all__"

class NewUserForm(forms.ModelForm):
    # class for creating new user Form 
    class Meta:
        model = All_User
        fields = ['name', 'Email', 'phone', 'password']

class Reserver_Product_Forms(forms.ModelForm):
    # class for creating form for reserver app
    class Meta:
        model = Reserve_products2
        fields = ['message']