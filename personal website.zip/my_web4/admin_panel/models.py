from django.db import models

# Create your models here.
class view_info(models.Model):
    name = models.CharField(max_length=200)
    ip = models.CharField(max_length=200)
    date = models.CharField(max_length=200)

class admin_info(models.Model):
    last_seen = models.CharField(max_length=200)
    status = models.CharField(max_length=100)
    