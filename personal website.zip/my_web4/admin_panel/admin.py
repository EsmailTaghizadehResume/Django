from django.contrib import admin
from admin_panel.models import view_info, admin_info

# Register your models here.
admin.site.register(view_info)
admin.site.register(admin_info)