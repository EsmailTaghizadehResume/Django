from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.modir, name='dashboard'),
    path('products/', views.product, name='products-manager'),
    path('users/', views.user, name='users-manager'),
    path('resume/', views.resume, name='resume-manager'),
    path('comments/', views.user_texts, name='comments-manager'),
    path('requests/', views.reserve, name='reserve-manager'),
    path('views/', views.view, name='payments-manager'),
    path('about-project/', views.about, name='about'),
    path('chat/', views.chats, name='chat'),
    path('delete-user/<int:idu>/', views.delete_acoount, name='delete'),
    path('delete-product/<int:idp>/', views.delete_product, name='delete-product'),
    path('delete-text/<int:idt>/', views.delete_text, name='delete-text'),
    path('delete-resume/<int:idr>/', views.delete_resume, name='delete-resume'),
    path('chat-with-user/<int:user_id>/', views.chat_with, name='chat_with')
]
