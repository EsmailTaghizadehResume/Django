from django.shortcuts import render, redirect
from .models import user_text2, Products, Resume_Project
from products_app.models import About, Reserve_products2
from accounts.models import All_User, All_Views, room, message
from admin_panel.forms import Reserver_Product_Forms
from admin_panel.models import admin_info
import datetime


USER = []
# Create your views here.
def home(requests):
    # this is now variable 
    now = datetime.datetime.now()
    now_date = now.strftime("%Y-%m-%d")
    # this is all querty in  database 
    resume = list(Resume_Project.objects.all())
    products = list(Products.objects.all())
    all_reseve = list(Reserve_products2.objects.all())
    # creating slice for just 3 from end to start in all product
    # this is a target list
    if len(products) == 0:
        all_products = []
    elif len(products) == 1:
        all_products = [products[0]]
    elif len(products) == 2:
        all_products = [products[0], products[1]]
    else:
        all_products = [products[-1], products[-2], products[-3]]
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 

    # this is conditions for saveing one data in day
    flag = False
    for _ in All_Views.objects.all():
        if _.ip == ip and _.date == now_date:
            flag = True
            break

    if flag == False:
        view = All_Views(ip=ip, date=now_date)
        view.save()

    users = All_User.objects.all()
    for i in users:
        if i.ip == ip:
            USER.append(i)
            count = 0
            for _ in all_reseve:
                if i.ip == _.ip:
                    count += 1
            return render(requests, 'index.html', {'alert':'user', 'items':all_products, 'resume':resume, 'user':USER[0], 'i':0 ,  'ReserveForms':Reserver_Product_Forms(), 'count':count})
    
    alert = False
    if requests.method == 'POST':
        flag = True
        all_users = user_text2.objects.all()
        for i in all_users:
            if i.name == requests.POST['name'] and i.phone == requests.POST['phone'] and i.message == requests.POST['message'] :
                flag = False
                break
        if flag:
            new_message = user_text2(name=requests.POST['name'], phone=requests.POST['phone'], message=requests.POST['message'], date=now_date)
            new_message.save()
            alert = True
            return render(requests, 'index.html', {'alert':alert, 'items':all_products, 'resume':resume, 'user':False, 'ReserveForms':Reserver_Product_Forms(), 'count':0})
        else:
            return render(requests, 'index.html', {'alert':alert, 'items':all_products, 'resume':resume, 'user':False, 'ReserveForms':Reserver_Product_Forms(), 'count':0})
    else:
        return render(requests, 'index.html', {'alert':alert, 'items':all_products, 'resume':resume, 'user':False, 'ReserveForms':Reserver_Product_Forms(), 'count':0})
    


def show_prodact(requests):
    products = list(Products.objects.all())
    cat = []
    for o in products:
        if o.category not in cat:
            cat.append(o.category)
    return render(requests, 'products.html' , {'items' : products, 'cat': cat})


def categoris(requests, category):
    products = list(Products.objects.all())
    items = []
    cat = []

    for o in products:
        if o.category == category:
            items.append(o)
            
        if o.category not in cat:
            cat.append(o.category)
    return render(requests, 'products.html' , {'items' : items, 'cat': cat})

def about(requests):
    all_abouts = About.objects.all()
    return render(requests, 'about_products.html', {'items':all_abouts})

def show_project(requests, idp):
    project_target = Resume_Project.objects.get(id=idp)
    return render(requests, 'project.html', {'i':project_target})


def error_404_view(requests, exceptions):
    return render(requests, '404.html', status=404)

def chat(requests):
    chatroom = None
    user_ = None
    flag = False
    # this is for time H:M
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M")
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 
    try:
        # finding user
        for i in list(All_User.objects.all()):
            if i.ip == ip:
                user_ = i
                flag = True
                break
         # catching the rooms 
        for _ in list(room.objects.all()):
            if _.email == user_.Email:
                chatroom = _
                chatroom.status = 'on'
                chatroom.save()
                break
        all_message = message.objects.filter(chat_room__email=chatroom.email).all()
    except:
        pass
    
    if requests.method == 'POST':
        try:
            new_message = message(chat_room = chatroom, time=current_time, text=requests.POST['text'], user='user')
            new_message.save()
            chatroom.start_at = True
            chatroom.save()
            return redirect(chat)
        except:
            pass
    
    else:
        if flag:
            return render(requests, 'chat/user_chat.html', {'room':chatroom, 'status':list(admin_info.objects.all())[-1].status, 'message':all_message})
            
        else:
            return render(requests, '404.html')
        

def checking(requests):
    # this code for having user ip adress my computer ip is : 127.0.0.1 this is home ip 
    x_forw_for = requests.META.get('HTTP_X_FORWARDED_FOR')
    if x_forw_for is not None:
        ip = x_forw_for.split(',')[0]
    else:
        ip = requests.META.get('REMOTE_ADDR') 
    
    # searching user for chatting
    for i in list(All_User.objects.all()):
        if i.ip == ip :
            return redirect(chat)
        
    else:
        return render(requests, 'error.html')