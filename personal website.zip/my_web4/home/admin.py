from django.contrib import admin
from .models import user_text2, Products, Resume_Project

# classes for displaying models
class user_text_edit(admin.ModelAdmin):
    readonly_fields = ['name', 'phone', 'message']
    list_display = ['name', 'phone']
    list_filter = ['name']

class items(admin.ModelAdmin):
    list_display = ['title', 'category']
    list_filter = ['category']

# Register your models here.
admin.site.register(user_text2, user_text_edit)
admin.site.register(Products, items)
admin.site.register(Resume_Project)