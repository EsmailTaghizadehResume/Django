from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('all-products/all/', views.show_prodact, name='products'),
    path('all-products/about/', views.about, name='about-products'),
    path('products/<str:category>/', views.categoris, name='cate'),
    path('projects/<int:idp>/', views.show_project, name='project'),
    path('booking-projects/', include('products_app.urls')),
    path('chat-with-admin/', views.chat, name='chat-user'),
    path('check-for-chat/', views.checking, name='chacking')
]
