from django.db import models

# Create your models here.
# this is not use
# ------------------------------------------
class user_text(models.Model):
    name = models.CharField(max_length=250)
    phone = models.CharField(max_length=50)
    message = models.TextField()
# ------------------------------------------

# this is updated
class user_text2(models.Model):
    name = models.CharField(max_length=250)
    date = models.CharField(max_length=30)
    phone = models.CharField(max_length=50)
    message = models.TextField()


class Products(models.Model):
    title = models.CharField(max_length=250)
    description = models.TextField()
    photo = models.ImageField(upload_to='products/')
    category = models.CharField(max_length=200)


class Resume_Project(models.Model):
    title = models.CharField(max_length=250)
    description = models.TextField()
    skills = models.CharField(max_length=250)
    time_to_finish = models.CharField(max_length=200)
    url = models.CharField(max_length=250)
    photo = models.ImageField(upload_to='resume/')